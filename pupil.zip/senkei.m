function z = senkei(B)
 z=B;
 figure;
 plot(z);
 title('size');
 xlabel('xlabel');
 ylabel('ylabel');
end

